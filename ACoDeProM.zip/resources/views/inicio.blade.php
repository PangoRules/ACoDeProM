@extends('base')

@section('estilos')

@endsection

@section('contenido')

@endsection