<?php $__env->startSection('estilos'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\ACoDeProM\resources\views/inicio.blade.php ENDPATH**/ ?>