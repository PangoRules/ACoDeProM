<?php $__env->startSection('estilos'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
	<div class="container mt-5">
		<h2 class="h1 text-center" style="margin-top:40px;">NUESTRA EMPRESA</h2>
		<p class="lead display-4 text-justify" style="font-size: 2rem !important; margin-top:20px;">Somos una empresa 100%  Mexicana con un pleno compromiso con la calidad y atención hacia nuestros cliente.
		Apegados a una sencilla y profesional solución para nuestros cliente, esto basándonos en nuestros mas de 10 años de experiencia en el medio  en los diferentes servicios y proyectos que ofrecemos.
		</p>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\ACoDeProM\resources\views/nuestraEmpresa.blade.php ENDPATH**/ ?>