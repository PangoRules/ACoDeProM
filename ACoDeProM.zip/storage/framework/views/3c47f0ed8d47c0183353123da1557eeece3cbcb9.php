<?php $__env->startSection('estilos'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
	<div class="container mt-5">
		<h2 class="display-1 text-center" style="margin-top:40px!important;">CONTACTO</h2>
		<div class="container text-center mt-5" style="margin-top:80px!important;">
			<h4 class="display-4">Teléfono para Ventas</h4>
			<p class="lead"><b>961-294-2885</b></p>
		</div>
		<div class="container text-center mt-5" style="margin-top:80px!important;">
			<h4 class="display-4">Correo Electrónico</h4>
			<p class="lead"><b>molinahdez67@hotmail.com</b></p>
			<p class="lead"><b>molinahdez67@gmail.com</b></p>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\ACoDeProM\resources\views/contacto.blade.php ENDPATH**/ ?>